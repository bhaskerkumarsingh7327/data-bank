import React from 'react'
import Weather from './Weather/Weather'

const App = () => {
  return (
    <div>
      <h1>Weather app</h1>
      <Weather/>
    </div>
  )
}

export default App
