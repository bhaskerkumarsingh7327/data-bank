import React, { useEffect, useState } from 'react'
import axios from 'axios'
// import './weather.css'

const Weather =  () => {
    const [weather, setWeather] = useState(null)
    const [city, setCity] = useState('New York')
    // const api = process.env.REACT_APP_WEATHERAPI    


    const getWeather = async () => {
        try {
            const response = await axios.get(`http://api.weatherapi.com/v1/current.json?key=861fcb82e72e46598ab81434242210&q=London&aqi=no`)
            setWeather(response.data)
            console.log(response.data)

        }
        catch (Error) {
            console.error("Error fetching weather data", error)
        }
    }
    useEffect(() => {
        getWeather()
    }, [])


    return (
        <div>
            <h1>Weather</h1>
        </div>
    )
}

export default Weather
