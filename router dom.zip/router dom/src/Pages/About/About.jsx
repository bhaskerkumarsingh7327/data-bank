import React from 'react'

const About = () => {
  return (
    <div>
      <h1>THDHKFJHEKJDHFKJHEWAFHWEQ</h1>
    </div>
  )
}

export default About
