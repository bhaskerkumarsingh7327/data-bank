import React from 'react'
import'./Contact.css'

const contact = () => {
  return (
    <div class="bh">
      <h1>This is Contact Us</h1>
          </div>
  )
}

export default contact

