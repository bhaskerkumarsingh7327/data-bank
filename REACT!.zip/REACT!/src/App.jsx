import React from 'react'
import NavBar from './Componeent/Navbar/Navbar'
import Footer from './Componeent/Footer/Footer'
import './App.css'


const App = () => {
  return (
    <div>
      <NavBar title ={'zomato.com'} city={'gurugram'}/>
      <div class="gum">

      </div>


     {/* <Contactus/> */}

<Footer/>



      

    </div>
  )
}

export default App

