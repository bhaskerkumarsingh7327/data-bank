import React, { useState } from 'react'
import'./App.css'

const App = () => {
  const [username,setusername]=useState("")
  const [Email,setEmail]=useState("")
  const [address,setaddress]=useState("")
  return (
    <div class="bg">
      <h1>sign up</h1>
      <h2>your username is {username}</h2>
      <h3>your Email is{Email} </h3>
      <h4>your address is {address}</h4>
      <form action="">
        <label htmlFor="">username</label>
       
        <br />
        <input type="text" value={username} onChange={(e)=>setusername(e.target.value)} placeholder='PRINCE'/>
        <br />

        <label htmlFor="">E-mail</label>
        <br />
        <input type="text" value={Email} onChange={(e)=>setEmail(e.target.value)} placeholder='PRINCE' />
        <br />

<label htmlFor="">address</label>
<br />
<input type="text" value={address} onChange={(e)=>setaddress(e.target.value)} placeholder='PRINCE' />



      </form>
    </div>
  )
}

export default App


