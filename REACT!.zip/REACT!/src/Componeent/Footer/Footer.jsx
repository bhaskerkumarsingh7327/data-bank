import React from 'react'
import'./Footer.css'
const Footer = () => {
  return (
    <div>
    
<footer>
  <p>Made By Bhasker Kumar singh</p>
  <p><a href="">saitm123@gmail.com</a></p>
</footer>
</div>
    
  )
}

export default Footer
