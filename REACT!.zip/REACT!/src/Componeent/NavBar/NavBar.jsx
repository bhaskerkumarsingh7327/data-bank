import React from 'react'
import './NavBar.css'
const NavBar = ({ title, city }) => {
  return (<>
    <div class="nav">
      <p class="logo">EXPRESSO</p>
      <p className='head'>welcome to {title}</p>
      <h1 className='none'>now serving 24*7 in your city {city}</h1>



      <ul class="navbar">
        <li id="home"><a href="">Home</a></li>
        <li class="About"><a href="">About</a></li>
        <li class="Service"><a href="">Service</a></li>
        <li class="Screenshot"><a href="">Screenshot</a></li>
        <li class="Blog"><a href="">Blog</a></li>
        <li class="contact us"><a href="">Contact us</a></li>
        <li class="search">
          <img src=".//assets/icons8-search-48.png" alt="" />
        </li>
      </ul>
    </div>

    

  </>
  )
}






export default NavBar   
